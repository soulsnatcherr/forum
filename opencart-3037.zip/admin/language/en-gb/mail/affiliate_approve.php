<?php
// Text
$_['text_subject']  = '%s - Your affiliate account has been activated!';
$_['text_welcome']  = 'Welcome and thank you for registering at %s!';
$_['text_login']    = 'Your account has now been approved and you can log in by using your email address and password by visiting our website or at the following URL:';
$_['text_services'] = 'Upon logging in, you will be able to generate tracking codes, track commission payments and edit your account information.';
$_['text_thanks']   = 'Thanks,';