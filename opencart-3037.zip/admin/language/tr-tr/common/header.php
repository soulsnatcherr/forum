<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Heading
$_['heading_title']      = 'OpenCart Türkçe';

// Text
$_['text_profile']       = 'Profilim';
$_['text_store']         = 'Mağazalar';
$_['text_help']          = 'Yardım';
$_['text_homepage']      = 'OpenCart Anasayfa';
$_['text_support']       = 'Forum Destek';
$_['text_documentation'] = 'Dökümantasyon';
$_['text_logout']        = 'Çıkış Yap';