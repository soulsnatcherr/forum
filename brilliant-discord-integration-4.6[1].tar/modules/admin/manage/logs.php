<?php

namespace IPS\brilliantdiscord\modules\admin\manage;

/* To prevent PHP errors (extending class does not exist) revealing path */

use IPS\brilliantdiscord\Request;
use IPS\brilliantdiscord\LoginHandler;
use IPS\brilliantdiscord\Maintenance\Log;
use IPS\brilliantdiscord\RateLimit;
use IPS\brilliantdiscord\Util\UnhandledDiscordException;

if (!defined('\IPS\SUITE_UNIQUE_KEY')) {
    header((isset($_SERVER['SERVER_PROTOCOL']) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0') . ' 403 Forbidden');
    exit;
}

/**
 * logs
 */
class _logs extends \IPS\Dispatcher\Controller
{
    /**
     * @brief	Has been CSRF-protected
     */
    public static $csrfProtected = TRUE;

    /**
     * Execute
     *
     * @return    void
     */
    public function execute()
    {
        \IPS\Dispatcher::i()->checkAcpPermission('brds_logs_manage');
        parent::execute();
    }

    /**
     * Manage
     *
     * @return    void
     */
    protected function manage()
    {
        /* Create the table */
        $table = new \IPS\Helpers\Table\Db('brilliantdiscord_logs', \IPS\Http\Url::internal('app=brilliantdiscord&module=manage&controller=logs'));

        $table->include = ['message', 'code', 'member', 'time'];
        $table->mainColumn = 'message';
        $table->langPrefix = 'brilliantdiscord_logs_';

        $table->tableTemplate = [\IPS\Theme::i()->getTemplate('tables', 'core', 'admin'), 'table'];
        $table->rowsTemplate = [\IPS\Theme::i()->getTemplate('tables', 'core', 'admin'), 'rows'];

        $table->rowButtons = function ($row) {
            $return = [];

            $return['info'] = [
                'icon' => 'info-circle',
                'title' => 'brilliantdiscord_logs_info',
                'data' => ['ipsDialog' => '', 'ipsDialog-title' => \IPS\Member::loggedIn()->language()->addToStack('brilliantdiscord_logs_info')],
                'link' => \IPS\Http\Url::internal('app=brilliantdiscord&module=manage&controller=logs&do=detailedInfo&id=') . $row['id'],
            ];

            return $return;
        };

        \IPS\Output::i()->sidebar['actions']['extended'] = [
            'icon' => 'file-text',
            'title' => \IPS\Settings::i()->brilliantdiscord_extended_logging ? 'brilliantdiscord_debug_disable' : 'brilliantdiscord_debug_enable',
            'link' => \IPS\Http\Url::internal('app=brilliantdiscord&module=manage&controller=logs&do=toggleDebug')
                ->csrf()->setQueryString([
                    'value' => (int) !\IPS\Settings::i()->brilliantdiscord_extended_logging
                ]),
        ];
        \IPS\Output::i()->sidebar['actions']['download'] = [
            'icon' => 'download',
            'title' => 'brilliantdiscord_debug_download',
            'primary' => true,
            'data' => ['ipsDialog' => '', 'ipsDialog-forceReload' => '', 'ipsDialog-title' => \IPS\Member::loggedIn()->language()->addToStack('brilliantdiscord_debug_dialog_title'), 'ipsDialog-size' => 'narrow'],
            'link' => \IPS\Http\Url::internal('app=brilliantdiscord&module=manage&controller=logs&do=exportSupportData'),
        ];

        $table->parsers = [
            'time' => function ($val, $row) {
                $t = \IPS\DateTime::ts($val);
                return $t->localeDate() . " " . $t->localeTime();
            },
            'member' => function ($val) {
                return \IPS\Member::load($val)->name;
            }
        ];

        /* Default sort options */
        $table->sortBy = $table->sortBy ?: 'time';
        $table->sortDirection = $table->sortDirection ?: 'desc';

        /* Display */
        \IPS\Output::i()->title = \IPS\Member::loggedIn()->language()->addToStack('brilliantdiscord_logs');
        \IPS\Output::i()->output = $table;
    }

    protected function detailedInfo()
    {
        try {
            $id = isset(\IPS\Request::i()->id) ? \IPS\Request::i()->id : NULL;
            if ($id == NULL || !is_numeric($id)) throw new \UnderflowException;
            $log = Log::load($id);
        } catch (\OutOfRangeException $e) {
            \IPS\Output::i()->error('node_error', '1SBR106/1', 404);
        }
        \IPS\Output::i()->output = \IPS\Theme::i()->getTemplate('configuration', 'brilliantdiscord')->logDetailed($log->exception_data, $log->message);
    }

    protected function exportSupportData()
    {
        if (!\IPS\Request::i()->confirm) {
            \IPS\Output::i()->title = \IPS\Member::loggedIn()->language()->addToStack('brilliantdiscord_debug_dialog_title');
            \IPS\Output::i()->output = \IPS\Theme::i()->getTemplate('management', 'brilliantdiscord')->debugAlert();
            return;
        }
        \IPS\Session::i()->csrfCheck();

        $errors = [];
        $gid = \IPS\Settings::i()->brilliantdiscord_guild;
        $loginHandler = \IPS\brilliantdiscord\LoginHandler::i();
        try {
            $guild = RateLimit::limitHandle('guilds/{guild.id}', $gid, function($check) use ($gid, &$errors) {
                // Basic request settings
                $request = new Request("guilds/$gid", ['with_counts' => 'true']);
                $request->applyDefaultHeaders();
                $request->bot();
                $response = $request->submit();

                // Check for rate limits
                $check($response);

                try {
                    $data = $response->decodeJson();
                    if ($response->httpResponseCode != 200) {
                        throw new \RuntimeException;
                    }
                    return $data;
                } catch (\RuntimeException $e) {
                    $errors['guild'] = [
                        'status' => $response->httpResponseCode,
                        'text' => $response->httpResponseText,
                        'headers' => $response->httpHeaders
                    ];
                }
                return null;
            });
            $channels = RateLimit::limitHandle('guilds/{guild.id}/channels', $gid, function($check) use ($gid, &$errors) {
                // Basic request settings
                $request = new Request("guilds/$gid/channels");
                $request->applyDefaultHeaders();
                $request->bot();
                $response = $request->submit();

                // Check for rate limits
                $check($response);

                try {
                    $data = $response->decodeJson();
                    if ($response->httpResponseCode != 200) {
                        throw new \RuntimeException;
                    }
                    return $data;
                } catch (\RuntimeException $e) {
                    $errors['channels'] = [
                        'status' => $response->httpResponseCode,
                        'text' => $response->httpResponseText,
                        'headers' => $response->httpHeaders
                    ];
                }
                return null;
            });
            $isClientSecretValid = true;
            try {
                if ($loginHandler == null) {
                    $isClientSecretValid = false;
                }
                $loginHandler->testSettings();
            } catch (\LogicException $e) {
                $isClientSecretValid = false;
            }
        } catch (RateLimit\RateLimitedException $e) {
            \IPS\Output::i()->error($e->ipsMessage(), '1sbr106/2', 429);
        }


        $data = [
            'url' => \IPS\Settings::i()->base_url,
            'requesterMemberId' => \IPS\Member::loggedIn()->member_id,
            'requesterDiscordId' => (\IPS\Member::loggedIn()->discordLink() ?: ['token_identifier' => null])['token_identifier'],
            'timestamp' => time(),
            'behavior' => iterator_to_array(\IPS\Db::i()->select(['key', 'value'], \IPS\brilliantdiscord\Behavior::$databaseTable)->setKeyField('key')->setValueField('value')),
            'settings' => [],
            'recentLogs' => iterator_to_array(\IPS\Db::i()->select('*', 'brilliantdiscord_logs', ['time >= ?', time() - 7776000], NULL, 150)),
            'clientSecretValid' => $isClientSecretValid,
            'discord' => [
                'guild' => $guild,
                'channels' => $channels,
            ],
            'stats' => [
                'websiteMemberCount' => \IPS\Db::i()->select('COUNT(*)', 'core_members')->first(),
                'linkedMemberCount' => LoginHandler::i() === null ? null : \IPS\Db::i()->select('COUNT(*)', 'core_login_links', ['token_login_method=?', LoginHandler::i()->id])->first()
            ],
            'groups' => array_map(function($group) {
                return [
                    'name' => \IPS\Member::loggedIn()->language()->get("core_group_$group->g_id"),
                    'discordRoles' => $group->discord_roles ?: [],
                    'approvalBypass' => $group->discord_bypass_approval
                ];
            }, \IPS\Member\Group::groups(true, false)),
            'errors' => $errors,
            'magicInvite' => array_map(function($invite) {
                return [
                    'url' => (string) $invite->url(),
                    'permissions' => $invite->permissions(),
                ];
            }, \IPS\brilliantdiscord\Invite::roots()),
            'loginHandlerSettings' => $loginHandler ? $loginHandler->settings : null
        ];

        // Settings
        $settings = [];
        $settingsToDump = ['configured', 'configured_guild', 'cid', 'guild', 'limit_syncprocessing', 'limit_syncretrieval'];
        foreach ($settingsToDump as $key) {
            $realKey = "brilliantdiscord_$key";
            $settings[$realKey] = \IPS\Settings::i()->$realKey;
        }
        $data['settings'] = $settings;

        unset($data['loginHandlerSettings']['client_secret'], $data['loginHandlerSettings']['client_id']); // Remove sensitive data
        $result = base64_encode(json_encode($data));

        $dateTime = (new \DateTime())->format('Y-m-d H:i:s');
        $filename = "BDI Debug Information $dateTime.dat";


        \IPS\Output::i()->sendHeader("Content-type: text/plain; charset=UTF-8");
        \IPS\Output::i()->sendHeader("Content-Disposition: " . \IPS\Output::getContentDisposition('attachment', $filename));

        print $result;
        exit;
    }

    protected function toggleDebug()
    {
        \IPS\Session::i()->csrfCheck();
        \IPS\Settings::i()->changeValues([
            'brilliantdiscord_extended_logging' => (int) (\IPS\Request::i()->value === '1')
        ]);
        \IPS\Output::i()->redirect(\IPS\Http\Url::internal('app=brilliantdiscord&module=manage&controller=logs'), 'brilliantdiscord_debug_info_' . (\IPS\Request::i()->value === '1' ? 'enabled' : 'disabled'));
    }
}