//<?php

/* To prevent PHP errors (extending class does not exist) revealing path */
if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	exit;
}

class brilliantdiscord_hook_loginHook extends _HOOK_CLASS_
{
    /**
     * Get methods which use a button
     *
     * @return	array
     */
    public function buttonMethods()
    {
	try
	{
	        $return = parent::buttonMethods();
	        if (!(\IPS\brilliantdiscord\LoginHandler::i()->settings['enable_logging_in'] ?? true) && debug_backtrace()[1]['function'] != 'authenticate') {
	            foreach ($return as $k => $method) {
	                if ($method->classname == 'IPS\brilliantdiscord\LoginHandler') {
	                    unset($return[$k]);
	                    break;
	                }
	            }
	        }
	        return $return;
	}
	catch ( \RuntimeException $e )
	{
		if ( method_exists( get_parent_class(), __FUNCTION__ ) )
		{
			return \call_user_func_array( 'parent::' . __FUNCTION__, \func_get_args() );
		}
		else
		{
			throw $e;
		}
	}
    }
}
