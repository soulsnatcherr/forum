<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Heading
$_['heading_title']  = 'Kontrol Paneli';

// Text
$_['text_heading']   = 'Kontrol Paneli';
$_['text_login']     = 'Lütfen bilgilerinizi giriniz.';
$_['text_forgotten'] = 'Parolamı Unuttum';

// Entry
$_['entry_username'] = 'Kullanıcı Adınız';
$_['entry_password'] = 'Parolanız';

// Button
$_['button_login']   = 'Oturum Aç';

// Error
$_['error_login']    = 'Kullanıcı adı ya da parola yanlış!';
$_['error_token']    = 'Geçersiz oturum. Lütfen tekrar oturum açın!';
$_['error_attempts'] = 'Uyarı: Oturum açma deneme sınırına ulaştınız. Lütfen 1 saat içinde tekrar deneyiniz!';