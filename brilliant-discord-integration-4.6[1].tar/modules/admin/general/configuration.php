<?php


namespace IPS\brilliantdiscord\modules\admin\general;

/* To prevent PHP errors (extending class does not exist) revealing path */

use IPS\brilliantdiscord\_Request;
use IPS\brilliantdiscord\Approval;
use IPS\brilliantdiscord\Maintenance\Log;
use IPS\brilliantdiscord\RateLimit;
use IPS\brilliantdiscord\RateLimit\RateLimitedException;
use IPS\brilliantdiscord\Request;
use IPS\brilliantdiscord\Util\_UnhandledDiscordException;
use IPS\brilliantdiscord\Util\UnhandledDiscordException;
use IPS\core\api\warnreasons;
use IPS\Task\Queue\OutOfRangeException;

if ( !defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

/**
 * configuration
 */
class _configuration extends \IPS\Dispatcher\Controller
{
    /**
     * @brief	Has been CSRF-protected
     */
    public static $csrfProtected = TRUE;

    public static $permissions = [
        'CREATE_INSTANT_INVITE' => 0x00000001,
        'KICK_MEMBERS' => 0x00000002,
        'MANAGE_CHANNELS' => 0x00000010,
        'MANAGE_GUILD' => 0x00000020,
        'VIEW_AUDIT_LOG' => 0x00000080,
        'MANAGE_NICKNAMES' => 0x08000000,
        'MANAGE_ROLES' => 0x10000000,
        'MANAGE_WEBHOOKS' => 0x20000000,
        'MANAGE_EMOJIS' => 0x40000000
    ];

	/**
	 * Execute
	 *
	 * @return	void
	 */
	public function execute()
	{
		\IPS\Dispatcher::i()->checkAcpPermission( 'brds_configuration_manage' );
		parent::execute();
	}

	/**
	 * ...
	 *
	 * @return	void
	 */
	protected function manage()
	{
        if (\IPS\Member::loggedIn()->hasAcpRestriction( 'brilliantdiscord', 'general', 'brds_configuration_clear_data' )) {
            \IPS\Output::i()->sidebar['actions']['clear'] = [
                'primary'	=> false,
                'icon'	=> 'trash-o',
                'title'	=> 'brilliantdiscord_configuration_clear',
                'link'	=> \IPS\Http\Url::internal( "app=brilliantdiscord&module=general&controller=configuration&do=clearData" )->csrf(),
            ];
        }
	    if (!\IPS\Settings::i()->brilliantdiscord_configured) {
	        // Begin configuration
            \IPS\Output::i()->cssFiles = array_merge(
                \IPS\Output::i()->cssFiles,
                \IPS\Theme::i()->css( 'general/begin.css', 'brilliantdiscord', 'admin' )
            );
            \IPS\Output::i()->output .= \IPS\Theme::i()->getTemplate( 'configuration', 'brilliantdiscord' )->begin();
        } else {
	        // Sidebar buttons
            \IPS\Output::i()->sidebar['actions']['reconfigure'] = [
                'primary'	=> false,
                'icon'	=> 'cogs',
                'title'	=> 'brilliantdiscord_configuration_reconfigure',
                'link'	=> \IPS\Http\Url::internal( "app=brilliantdiscord&module=general&controller=configuration&do=advancedSetup&_new=1" ),
            ];
            \IPS\Output::i()->sidebar['actions']['masssync'] = [
                'primary' => false,
                'icon' => 'refresh',
                'title' => 'brilliantdiscord_mass_sync_button',
                'link' => \IPS\Http\Url::internal("app=brilliantdiscord&module=general&controller=configuration&do=masssync")
            ];

            // Details editing form
            $form = new \IPS\Helpers\Form;
            $p = 'brilliantdiscord_wza_'; // Prefix

            // Tab 1. General settings
            $form->addTab($p.'general_tab');

            // Had we configured guild settings?
            $conf_g = \IPS\Settings::i()->brilliantdiscord_configured_guild;

            // We want to display a information about detected problems BEFORE everything, and after verifying values:
            // 1. We put blank information
            // 2. Then we edit it
            $form->addHtml('');

            // Client ID (application) can't be changed without changing everything.
            $form->add(new \IPS\Helpers\Form\Text($p . 'client_id', \IPS\Settings::i()->brilliantdiscord_cid, TRUE, ['disabled' => TRUE]));

            // But we allow editing changeable values:
            $form->add(new \IPS\Helpers\Form\Text($p . 'client_secret', \IPS\Settings::i()->brilliantdiscord_secret, TRUE));
            $form->add(new \IPS\Helpers\Form\Text($p . 'token', \IPS\Settings::i()->brilliantdiscord_token, TRUE));

            // Validate & save changed values
            if ($values = $form->values()) {
                // Delete prefixes
                foreach ($values as $k => $v) {
                    if (mb_substr($k, 0, 21) == $p) {
                        $values[mb_substr($k, 21)] = trim($v); // ...and trim values
                        unset($values[$k]);
                    }
                }

                // Verify token
                try {
                    RateLimit::limitHandle('oauth2/applications/@me', NULL, function ($check) use ($values, $form, $p) {
                        // Basic request settings
                        $request = new Request('oauth2/applications/@me');
                        $request->bot($values['token']);
                        $request->applyDefaultHeaders();

                        $response = $request->submit();
                        // Parse rate limits
                        $check($response);

                        // Anything's wrong?
                        if ($response->httpResponseCode != 200) {
                            switch ($response->httpResponseCode) {
                                case 401: // Unauthorized - token is invalid
                                    $form->elements[$p.'general_tab'][$p.'token']->error = \IPS\Member::loggedIn()->language()->addToStack('brilliantdiscord_error_invalid_token');
                                    break;
                                default: // TODO handling more errors?
                                    $form->error = \IPS\Member::loggedIn()->language()->addToStack('generic_error'); // Something went wrong
                            }
                        } else {
                            // Check if this is token of the same app
                            try {
                                $json = $response->decodeJson();
                                if ($json['id'] == $values['client_id']) {
                                    // Confirmed, we can save data.
                                    $d = ['token' => 'token', 'client_secret' => 'secret'];
                                    foreach ($d as $k => $v) {
                                        $v = 'brilliantdiscord_' . $v;
                                        \IPS\Db::i()->update('core_sys_conf_settings', ['conf_value' => $values[$k]], ['conf_key=?', $v]);
                                        \IPS\Settings::i()->$v = $values[$k];
                                    }
                                    unset(\IPS\Data\Store::i()->settings);
                                } else {
                                    // Inconsistent data
                                    $form->elements[$p.'general_tab'][$p.'token']->error = \IPS\Member::loggedIn()->language()->addToStack('brilliantdiscord_error_inconsistent_token');
                                }
                            } catch (\RuntimeException $e) {
                                // Something went wrong :(
                                $form->error = \IPS\Member::loggedIn()->language()->addToStack('generic_error');
                            }
                        }
                    });
                } catch ( RateLimitedException $e ) {
                    $form->error = $e->ipsMessage();
                    \IPS\Output::i()->output = $form;
                }
            }

            // Information about problems
            $problems = $this->_findProblems($conf_g ? \IPS\Settings::i()->brilliantdiscord_guild : NULL);
            $form->elements[$p.'general_tab'][0] = \IPS\Theme::i()->getTemplate('configuration', 'brilliantdiscord')->appInfo($problems);
            \IPS\Output::i()->output = $form;
        }
		\IPS\Output::i()->title  = \IPS\Member::loggedIn()->language()->addToStack('brilliantdiscord_configuration');
	}

	protected function advancedSetup()
    {
        // Configuration check
        $conf = \IPS\Settings::i()->brilliantdiscord_configured;
        $conf_g = \IPS\Settings::i()->brilliantdiscord_configured_guild;

        $gotoguild = $conf && isset(\IPS\Request::i()->gotoguild);
        \IPS\Output::i()->cssFiles = array_merge(
            \IPS\Output::i()->cssFiles,
            \IPS\Theme::i()->css( 'general/misc.css', 'brilliantdiscord', 'admin' )
        );
        \IPS\Output::i()->jsFiles = array_merge(
            \IPS\Output::i()->jsFiles,
            \IPS\Output::i()->js('admin_config.js', 'brilliantdiscord' )
        );
        $wizard = new \IPS\Helpers\Wizard(
            [
                'brilliantdiscord_wza_step1' => function ($data) use ($conf, $gotoguild) {
                    if ($gotoguild) {
                        return [
                            'client_id' => \IPS\Settings::i()->brilliantdiscord_cid,
                            'client_secret' => \IPS\Settings::i()->brilliantdiscord_secret,
                            'token' => \IPS\Settings::i()->brilliantdiscord_token
                        ];
                    }
                    $p = 'brilliantdiscord_wza_'; // Prefix
                    $form = new \IPS\Helpers\Form('form1', 'brilliantdiscord_configure_next');

                    // Information about redirect URIs
                    $form->addHtml(\IPS\Theme::i()->getTemplate('configuration', 'brilliantdiscord')->info(
                        \IPS\Member::loggedIn()->language()->addToStack('brilliantdiscord_wza_app_info')
                    ));
                    $form->addHtml(\IPS\Theme::i()->getTemplate('configuration', 'brilliantdiscord')->info(
                        \IPS\Member::loggedIn()->language()->addToStack('brilliantdiscord_wza_redi_uri_info')
                    ));

                    // Fields
                    $form->add(new \IPS\Helpers\Form\Text($p . 'client_secret', $conf ? \IPS\Settings::i()->brilliantdiscord_secret : NULL, TRUE));
                    $form->add(new \IPS\Helpers\Form\Text($p . 'token', $conf ? \IPS\Settings::i()->brilliantdiscord_token : NULL, TRUE));

                    if ($values = $form->values()) {
                        // Delete prefixes
                        foreach ($values as $k => $v) {
                            if (mb_substr($k, 0, 21) == $p) {
                                $values[mb_substr($k, 21)] = trim($v);
                                unset($values[$k]);
                            }
                        }

                        // Validate token
                        $request = new Request('oauth2/applications/@me');
                        $request->applyDefaultHeaders();
                        $request->bot($values['token']);
                        $response = $request->submit();

                        // Something is wrong?
                        if ($response->httpResponseCode != 200) {
                            switch ($response->httpResponseCode) {
                                case 401: // Unauthorized - token is invalid
                                    $form->elements[''][$p.'token']->error = \IPS\Member::loggedIn()->language()->addToStack('brilliantdiscord_error_invalid_token');
                                    return $form;
                                default: // TODO handling more errors?
                                    $exception = new UnhandledDiscordException($request, $response);
                                    $exception->safeHandle(FALSE);
                                    $form->error = \IPS\Member::loggedIn()->language()->addToStack('generic_error'); // Probably connection error, etc.
                                    return $form;
                            }
                        }
                        // Save Client ID
                        $values['client_id'] = $response->decodeJson()['id'];
                        \IPS\Settings::i()->changeValues([
                            'brilliantdiscord_cid' => $values['client_id']
                        ]);
                        return $values;
                    }

                    return $form;
                },
                'brilliantdiscord_wza_step2' => function ($data) use ($conf_g) {
                    $form = new \IPS\Helpers\Form('form2', 'brilliantdiscord_configure_next');
                    $p = 'brilliantdiscord_wza_'; // Prefix

                    // User should know that this is always configurable later
                    $form->addHtml(\IPS\Theme::i()->getTemplate('configuration', 'brilliantdiscord')->info(
                        \IPS\Member::loggedIn()->language()->addToStack('brilliantdiscord_configurable_later')
                    ));

                    // Enable guild integration (deep lvl 1)?
                    $form->add( new \IPS\Helpers\Form\YesNo($p.'enable_deep1', TRUE, FALSE));

                    $addURL = \IPS\Http\Url::external('https://discordapp.com/api/oauth2/authorize')->setQueryString([
                        'scope' => 'bot',
                        'client_id' => $data['client_id'],
                        'permissions' => array_sum(static::$permissions)
                    ]);
                    $exchangeURL = \IPS\Http\Url::internal('app=brilliantdiscord&module=general&controller=guildData')->setQueryString('token', $data['token']);

                    // Guild helper
                    $form->add(new \IPS\Helpers\Form\Custom($p.'guild', $conf_g ? \IPS\Settings::i()->brilliantdiscord_guild : -1, NULL, [
                        'getHtml'	=> function( $field ) use ( $addURL, $exchangeURL ) {
                            return \IPS\Theme::i()->getTemplate( 'configuration', 'brilliantdiscord' )->guildHelper( $field,
                                $exchangeURL, $addURL, $field->value
                            );
                        },
                        'validate'  => function( $field ) use ( $data ) {
                            if ($field->value == '__EMPTY') {
                                if ($field->required) {
                                    throw new \DomainException('form_required');
                                }
                                return;
                            }
                            try {
                                RateLimit::limitHandle('users/@me/guilds', NULL, function($check) use ($field, $data) {
                                    // Basic request settings
                                    $request = new Request("users/@me/guilds", $this->_guildFindQuery($field->value));
                                    $request->applyDefaultHeaders();
                                    $request->bot($data['token']);
                                    $response = $request->submit();

                                    // Check for rate limits
                                    $check($response);

                                    // Parse response
                                    if ($response->httpResponseCode != 200) {
                                        switch ($response->httpResponseCode) {
                                            // Something bad happened
                                            default:
                                                throw new \DomainException('generic_error');
                                        }
                                    } elseif (!$response->decodeJson()) {
                                        throw new \DomainException('brilliantdiscord_error_no_guild_access');
                                    } elseif ($missing = static::_missingPermissions(static::$permissions, (int) $response->decodeJson()[0]['permissions'])) {
                                        throw new \DomainException(\IPS\Member::loggedIn()->addToStack('brilliantdiscord_error_permissions', FALSE,
                                            ['sprintf' => implode(", ", $missing)]
                                        ));
                                    }
                                });
                            } catch (RateLimitedException $e) {
                                throw new \DomainException($e->ipsMessage());
                            }
                        }
                    ], NULL, NULL, NULL, 'guild'));

                    // Parse values
                    if ($values = $form->values()) {
                        $return = $data;
                        foreach (['guild'] as $v) {
                            $return[$v] = $values[$p . $v];
                        }
                        if ($values[$p.'enable_deep1']) {
                            if ($return['guild'] == '__EMPTY') {
                                $form->elements[''][$p.'guild']->error = \IPS\Member::loggedIn()->language()->addToStack('form_required');
                                return $form;
                            }
                        } else {
                            $return['guild'] = -1;
                        }
                        return $return;
                    }
                    return $form;
                },
                'brilliantdiscord_wza_step3' => function ($data) use ($conf_g) {
                    if ($data['guild'] == -1) return $data;

                    $form = new \IPS\Helpers\Form;
                    try {
                        $roles = ['no_role' => ''];
                        foreach (\IPS\brilliantdiscord\Util\Guild::roles($data['guild'], $data['token']) as $k => $v) $roles[$k] = $v;
                        $form->add( new \IPS\Helpers\Form\Select( 'brilliantdiscord_behavior_form_basic_role', $conf_g ? \IPS\brilliantdiscord\Behavior::i()->basic_role : 'no_role', TRUE, ['parse' => 'normal', 'options' => $roles], function($val) {
                            if ($val == 'no_role') {
                                throw new \DomainException('form_required');
                            }
                        } ) );
                    } catch (RateLimitedException $e) {
                        $form->add( new \IPS\Helpers\Form\Select( 'brilliantdiscord_behavior_form_basic_role', $conf_g ? \IPS\brilliantdiscord\Behavior::i()->basic_role : 'no_role', TRUE, ['parse' => 'normal', 'options' => ['no_role' => '']], function($val) {
                            if ($val == 'no_role') {
                                throw new \DomainException('form_required');
                            }
                        } ) );
                        $form->elements['']['brilliantdiscord_behavior_form_basic_role']->error = $e->ipsMessage();
                    }

                    if ($values = $form->values()) {
                        \IPS\brilliantdiscord\Behavior::i()->basic_role = $values['brilliantdiscord_behavior_form_basic_role'];
                        return $data;
                    }
                    return $form;
                },
                'brilliantdiscord_wza_step4' => function ($data) use ($conf, $conf_g) {
                    $form = new \IPS\Helpers\Form('form4');

                    // Display an user-friendly information
                    $form->addHtml(\IPS\Theme::i()->getTemplate('configuration', 'brilliantdiscord')->allDone());

                    if ($form->values() !== FALSE) {
                        // Additional settings, just for easy check if app is configured or not
                        $data['configured'] = TRUE;
                        $data['configured_guild'] = $data['guild'] != -1;

                        // Save settings
                        $d = [];
                        foreach (['configured', 'configured_guild', 'token', 'guild'] as $v) {
                            $d['brilliantdiscord_' . $v] = $data[$v];
                        }
                        $d['brilliantdiscord_secret'] = $data['client_secret'];
                        \IPS\Settings::i()->changeValues($d);

                        // Enable login handler, as we had just configured it
                        \IPS\Db::i()->update('core_login_methods', ['login_enabled' => TRUE], ['login_classname=?', 'IPS\brilliantdiscord\LoginHandler']);
                        unset(\IPS\Data\Store::i()->loginMethods);

                        // If reconfigured and guild has changed - delete roles from group data
                        if ($conf_g && $data['guild'] != \IPS\Settings::i()->brilliantdiscord_guild) {
                            \IPS\Db::i()->update('brilliantdiscord_groupdata', ['discord_roles' => NULL]);
                        }

                        // Finished - redirect to the configuration overview
                        \IPS\Output::i()->redirect(\IPS\Http\Url::internal('app=brilliantdiscord&module=general&controller=configuration'), 'saved');
                    }
                    return $form;
                }
            ],
            \IPS\Http\Url::internal('app=brilliantdiscord&module=general&controller=configuration&do=advancedSetup' . ($gotoguild ? '&gotoguild=1' : ''))
        );
        \IPS\Output::i()->title = \IPS\Member::loggedIn()->language()->addToStack('brilliantdiscord_wza_title');
        \IPS\Output::i()->output = $wizard;
    }

    public static function _missingPermissions($expected, $actual, $acceptAdministrator = TRUE)
    {
        if ($acceptAdministrator && ($actual & 8) == 8) {
            return [];
        }
        $missing = [];
        foreach ($expected as $k => $v) {
            if (($v & $actual) == 0) {
                $missing[] = $k;
            }
        }
        return $missing;
    }

    protected function _findProblems($guild = NULL)
    {
        $request = new Request("users/@me/guilds", $guild ? $this->_guildFindQuery($guild) : []);
        $request->bot();
        $request->applyDefaultHeaders();
        $response = $request->submit();
        $dataInfo = ['error' => NULL];
        try {
            $json = $response->decodeJson();
        } catch (\RuntimeException $e) {
            return ['error' => 'generic'];
        }
        if ($response->httpResponseCode != 200) {
            switch ($response->httpResponseCode) {
                case 401:
                    $dataInfo['error'] = 'badtoken';
                    break;
                default:
                    $dataInfo['error'] = 'generic';
            }
        } elseif ($guild && (!$json || $json[0]['id'] != $guild)) {
            $dataInfo['error'] = 'glost';
        } elseif ($guild && $perms = static::_missingPermissions(static::$permissions, (int) $json[0]['permissions'])) {
            $dataInfo['error'] = 'perms';
            $dataInfo['missingPerms'] = $perms;
        }
        return $dataInfo;
    }

    protected function _guildFindQuery($id) {
	    $query = ['limit' => 1];
	    switch (mb_substr($id, -1)) {
            case '0':
                $query['after'] = \intval($id) - 1;
                break;
            default:
                $query['after'] = mb_substr($id, 0, -1) . (\intval(mb_substr($id, -1)) - 1);
        }
        return $query;
    }

    protected function clearData() {
	    \IPS\Session::i()->csrfCheck();
	    \IPS\Dispatcher::i()->checkAcpPermission('brds_configuration_clear_data');
        $p = 'brilliantdiscord_cldf_';
	    $form = new \IPS\Helpers\Form('form', $p.'proceed');
	    $form->addHtml(\IPS\Theme::i()->getTemplate('configuration', 'brilliantdiscord')->info(\IPS\Member::loggedIn()->language()->addToStack($p.'warning'), FALSE, 'warning'));
	    $options = [];
	    $configuration = [];
        foreach (['behavior', 'groups'] as $v) $configuration[$v] = $p.$v;
        foreach (['ratelimits', 'member_links', 'logs'] as $v) $options[$v] = $p.$v;
        $form->add( new \IPS\Helpers\Form\YesNo($p.'full_conf', FALSE, FALSE, ['togglesOff' => ['configuration_checks']]) );
	    $form->add( new \IPS\Helpers\Form\CheckboxSet($p.'configuration', [], FALSE, ['options' => $configuration], NULL, NULL, NULL, 'configuration_checks') );
	    $form->add( new \IPS\Helpers\Form\CheckboxSet($p.'another', [], FALSE, ['options' => $options]) );

	    if ($values = $form->values()) {
	        $options = \is_array($values[$p.'another']) ? $values[$p.'another'] : [$values[$p.'another']];
	        foreach ($options as $v) {
	            switch ($v) {
                    case "ratelimits":
                        \IPS\Db::i()->delete('brilliantdiscord_ratelimits');
                        break;
                    case "logs":
                        \IPS\Db::i()->delete('brilliantdiscord_logs');
                        break;
                    case "member_links":
                        \IPS\Db::i()->delete('core_login_links', ['`token_login_method`=?', \IPS\Login\Handler::findMethod(\IPS\brilliantdiscord\LoginHandler::class)->id]);
                        break;
                }
            }
	        if ($values[$p.'full_conf']) {
                \IPS\Settings::i()->changeValues([
                    'brilliantdiscord_configured' => FALSE,
                    'brilliantdiscord_configured_guild' => FALSE,
                ]);
                \IPS\brilliantdiscord\Behavior::i()->resetToDefault();
                \IPS\Db::i()->delete('brilliantdiscord_groupdata');
                \IPS\Db::i()->update('core_login_methods', ['login_enabled' => FALSE], ['login_classname=?', 'IPS\brilliantdiscord\LoginHandler']);
                unset(\IPS\Data\Store::i()->loginMethods);

            } else {
                $conf = \is_array($values[$p.'configuration']) ? $values[$p.'configuration'] : [$values[$p.'configuration']];
                foreach ($conf as $v) {
                    switch ($v) {
                        case "behavior":
                            \IPS\brilliantdiscord\Behavior::i()->resetToDefault();
                            break;
                        case "groups":
                            \IPS\Db::i()->delete('brilliantdiscord_groupdata');
                            break;
                    }
                }
            }
	        \IPS\Output::i()->redirect(\IPS\Http\Url::internal('app=brilliantdiscord&module=general&controller=configuration'), 'brilliantdiscord_success');
        }
	    \IPS\Output::i()->title = \IPS\Member::loggedIn()->language()->addToStack($p.'title');
	    \IPS\Output::i()->output = $form;
    }

    public function masssync()
    {
        \IPS\Output::i()->title = \IPS\Member::loggedIn()->language()->addToStack('brilliantdiscord_mass_sync');
        if (!isset(\IPS\Request::i()->state)) {
            \IPS\Output::i()->output = \IPS\Theme::i()->getTemplate('configuration', 'brilliantdiscord', 'admin')->massSyncBegin();
            return;
        }
        if (\IPS\Request::i()->state == 'begin') {
            \IPS\Session::i()->csrfCheck();
            $gid = \IPS\Settings::i()->brilliantdiscord_guild;
            try {
                $guildData = null;
                RateLimit::limitHandle('guilds/{guild.id}', $gid, function($check) use ($gid, &$guildData) {
                    // Basic request settings
                    $request = new Request("guilds/$gid", ['with_counts' => 'true']);
                    $request->applyDefaultHeaders();
                    $request->bot();
                    $response = $request->submit();

                    // Check for rate limits
                    $check($response);

                    try {
                        $guildData = $response->decodeJson();
                    } catch (\RuntimeException $e) {
                        Log::log($e);
                        \IPS\Output::i()->error('brilliantdiscord_support_error', '5sbr108/8');
                    }

                    // Parse response
                    if ($response->httpResponseCode != 200) {
                        // Missing Access
                        if ($guildData['code'] == 50001) {
                            \IPS\Output::i()->error('brilliantdiscord_error_no_guild_access', '4sbr108/9');
                        }
                        (new UnhandledDiscordException($request, $response))->safeHandle(TRUE, '4sbr108/7', 'brilliantdiscord_err_mass_sync_guild_failed');
                    }
                });
                RateLimit::limitHandle('guilds/{guild.id}/members', $gid, function($check) use ($gid, &$guildData) {
                    // Basic request settings
                    $mid = \IPS\Settings::i()->brilliantdiscord_cid;
                    $request = new Request("guilds/$gid/members");
                    $request->applyDefaultHeaders();
                    $request->bot();
                    $response = $request->submit();

                    // Check for rate limits
                    $check($response);

                    try {
                        $json = $response->decodeJson();
                    } catch (\RuntimeException $e) {
                        Log::log($e);
                        \IPS\Output::i()->error('brilliantdiscord_support_error', '5sbr108/11');
                    }

                    // Parse response
                    if ($response->httpResponseCode != 200) {
                        if ($json['code'] == 50001) {
                            \IPS\Output::i()->error('brilliantdiscord_error_no_members_intent', '4sbr108/13');
                        }
                        (new UnhandledDiscordException($request, $response))->safeHandle(TRUE, '4sbr108/12', 'brilliantdiscord_err_mass_sync_guild_failed');
                    }
                });
                $return = RateLimit::limitHandle('guilds/{guild.id}/members/{member.id}', $gid, function($check) use ($gid, &$guildData) {
                    // Basic request settings
                    $mid = \IPS\Settings::i()->brilliantdiscord_cid;
                    $request = new Request("guilds/$gid/members/$mid");
                    $request->applyDefaultHeaders();
                    $request->bot();
                    $response = $request->submit();

                    // Check for rate limits
                    $check($response);

                    try {
                        $json = $response->decodeJson();
                    } catch (\RuntimeException $e) {
                        Log::log($e);
                        \IPS\Output::i()->error('brilliantdiscord_support_error', '5sbr108/2');
                    }

                    // Parse response
                    if ($response->httpResponseCode != 200) {
                        (new UnhandledDiscordException($request, $response))->safeHandle(TRUE, '4sbr108/10', 'brilliantdiscord_err_mass_sync_guild_failed');
                    }

                    $roles = [];
                    foreach ($guildData['roles'] as $role) {
                        $roles[$role['id']] = $role;
                    }

                    $maxPositionRole = null;
                    foreach ($json['roles'] as $role) {
                        if ($maxPositionRole == null) {
                            $maxPositionRole = $role;
                            continue;
                        }
                        $oldRolePosition = $roles[$maxPositionRole]['position'];
                        $newRolePosition = $roles[$role]['position'];
                        if ($oldRolePosition < $newRolePosition || ($oldRolePosition == $newRolePosition && $maxPositionRole < $role)) {
                            $maxPositionRole = $role;
                        }
                    }

                    $count = 0;
                    $botsBestPosition = $roles[$maxPositionRole]['position'];
                    foreach ($roles as $id => $role) {
                        if ($role['position'] > $botsBestPosition || $role['position'] == $botsBestPosition && $id < $maxPositionRole) {
                            $count++;
                        }
                    }

                    if ($count != 0) {
                        \IPS\Output::i()->title = \IPS\Member::loggedIn()->language()->addToStack('500_error_title');
                        \IPS\Output::i()->output = \IPS\Theme::i()->getTemplate('configuration', 'brilliantdiscord')->massSyncRolesIssue($count, $roles[$maxPositionRole]['name']);
                        return 'do_not_continue';
                    }
                    return null;
                });
                if ($return == 'do_not_continue') {
                    return;
                }
            } catch (RateLimitedException $e) {
                \IPS\Output::i()->error(\IPS\Member::loggedIn()->language()->addToStack('brilliantdiscord_err_rl_bef_msync', false, ['sprintf' => $e->timeLeft()]), '1sbr108/6');
            }
            \IPS\Output::i()->redirect(\IPS\Http\Url::internal('app=brilliantdiscord&module=general&controller=configuration&do=masssync&state=process')->csrf());
        }
        if (\IPS\Request::i()->state == 'process') {
            \IPS\Session::i()->csrfCheck();
            $multiRedirect = new \IPS\Helpers\MultipleRedirect(
                \IPS\Http\Url::internal('app=brilliantdiscord&module=general&controller=configuration&do=masssync&state=process')->csrf(),
                function($data) {
                    // $data contains:
                    // 'wait_until' => in case of a rate limit, timestamp to wait until
                    // 'to_sync' => count of members to sync
                    // 'members' => APPROXIMATE member count
                    // 'checked' => how many members have been checked during the retrieval
                    // 'done' => members synced so far

                    $gid = \IPS\Settings::i()->brilliantdiscord_guild;
                    $handlerId = \IPS\brilliantdiscord\LoginHandler::i()->id;

                    //region Phase 0 - wait until rate limits expire
                    if (\is_array($data) and isset($data['wait_until']) and $data['wait_until'] != -1 and $data['wait_until'] >= time()) {
                        usleep((max(5, time() - $data['wait_until'])) * 1000000);
                        $key = 'brilliantdiscord_mass_sync_prog_' . ($data['complete'] ? 'syncing' : 'init');
                        $settings = $data['complete'] ? ['sprintf' => [$data['checked'], $data['members'], $data['synced']]] : [];
                        $progress = $data['complete'] ? min(0, max(100, round($data['checked'] / ($data['members'] ?: 1)))) : 0;

                        return [$data, \IPS\Member::loggedIn()->language()->addToStack($key, false, $settings), $progress];
                    }
                    //endregion

                    try {
                        //region Phase 1 - get guild information and set initial data
                        if (!\is_array($data) || !$data['complete']) {
                            RateLimit::limitHandle('guilds/{guild.id}', $gid, function($check) use ($gid, &$count, &$ownerId) {
                                // Basic request settings
                                $request = new Request("guilds/$gid", ['with_counts' => 'true']);
                                $request->applyDefaultHeaders();
                                $request->bot();
                                $response = $request->submit();

                                // Check for rate limits
                                $check($response);

                                // Parse response
                                if ($response->httpResponseCode != 200) {
                                    (new UnhandledDiscordException($request, $response))->safeHandle(TRUE, '4sbr108/1', 'brilliantdiscord_err_mass_sync_guild_failed');
                                }

                                try {
                                    $json = $response->decodeJson();
                                } catch (\RuntimeException $e) {
                                    Log::log($e);
                                    \IPS\Output::i()->error('brilliantdiscord_support_error', '5sbr108/2');
                                }

                                $count = $json['approximate_member_count'];
                                $ownerId = $json['owner_id'];
                            });

                            $newData = ['wait_until' => -1,
                                'to_sync' => 0,
                                'checked' => 0,
                                'last_checked_id' => 0,
                                'members' => $count,
                                'synced' => -1,
                                'complete' => true,
                                'owner_id' => $ownerId
                            ];
                            Log::logDebugMessage("[Mass Sync] Started with the following data: \n\n" . \json_encode($newData));
                            return [$newData, \IPS\Member::loggedIn()->language()->addToStack('brilliantdiscord_mass_sync_prog_init', false, ['sprintf' => [0, $count, 0]]), 0];
                        }
                        // endregion

                        if (!isset($data['assignments'])) {
                            $data['assignments'] = [];
                            foreach (\IPS\Member\Group::groups(TRUE, FALSE) as $v) {
                                $data['assignments'][$v->g_id] = $v->discord_roles ?: [];
                            }
                            Log::logDebugMessage("[Mass Sync] Determined role assignments: \n\n" . \json_encode($data['assignments']));
                        }
                        $groupRoleAssignments = $data['assignments'];

                        // region Phase 3 - find members which require synchronization
                        $hardMemberLimit = min(1000, \IPS\Settings::i()->brilliantdiscord_limit_syncretrieval);
                        $result = RateLimit::limitHandle('guilds/{guild.id}/members', $gid, function ($check) use ($gid, $handlerId, $groupRoleAssignments, &$data, $hardMemberLimit) {
                            // Basic request settings
                            $request = new Request("guilds/$gid/members", ['limit' => $hardMemberLimit, 'after' => $data['last_checked_id']]);
                            $request->applyDefaultHeaders();
                            $request->bot();
                            $response = $request->submit();

                            // Check for rate limits
                            $check($response);

                            if ($response->httpResponseCode != 200) {
                                (new UnhandledDiscordException($request, $response))->safeHandle(TRUE, '4sbr108/3', 'brilliantdiscord_err_mass_sync_members_failed');
                            }

                            try {
                                $json = $response->decodeJson();
                            } catch (\RuntimeException $e) {
                                Log::log($e);
                                \IPS\Output::i()->error('brilliantdiscord_support_error', '5sbr108/4');
                            }

                            foreach ($json as $user) {
                                $userId = $user['user']['id'];

                                if ($userId == $data['owner_id']) {
                                    $data['checked']++;
                                    continue;
                                }
                                $name = $user['nick'] ?: $user['user']['username'];
                                try {
                                    $member = \IPS\Db::i()->select(
                                        ['name', 'member_group_id', 'mgroup_others', 'token_member'],
                                        'core_login_links',
                                        ['token_identifier=? AND token_login_method=?', $userId, $handlerId]
                                    )->join(
                                        'core_members',
                                        'core_login_links.token_member = core_members.member_id',
                                        'INNER'
                                    )->first();

                                    // Check for nickname
                                    $syncNeeded = \IPS\brilliantdiscord\Behavior::i()->sync_nicknames && $member['name'] != $name;

                                    // Role checks
                                    $collector = [\IPS\brilliantdiscord\Behavior::i()->basic_role => TRUE];
                                    $groupIds = explode(',', $member['mgroup_others']);
                                    $groupIds[] = $member['member_group_id'];

                                    // Disallow all managed roles
                                    foreach ($groupRoleAssignments as $roles) {
                                        foreach ($roles as $role) {
                                            $collector[$role] = FALSE; // Member can't have it
                                        }
                                    }
                                    // But allow (and require having) roles assigned to member's groups
                                    foreach ($groupIds as $groupId) {
                                        foreach ($groupRoleAssignments[$groupId] ?? [] as $role) {
                                            $collector[$role] = TRUE; // Member must have it
                                        }
                                    }

                                    foreach ($user['roles'] as $role) {
                                        $status = $collector[$role] ?? null;
                                        // Mark required role as assigned
                                        if ($status === TRUE) {
                                            $collector[$role] = null;
                                        } // Disallowed role present? Then synchronization is required
                                        elseif ($status === FALSE) {
                                            unset($collector[$role]);
                                            $syncNeeded = TRUE;
                                        } else {
                                            $collector[$role] = null;
                                        }
                                    }

                                    // Still there? Maybe we have some required, but nonassigned roles?
                                    $syncNeeded = $syncNeeded || \in_array(TRUE, $collector, TRUE);

                                    if ($syncNeeded) {
                                        $collector = \array_filter($collector, function($v) {
                                            return $v !== FALSE;
                                        });
                                        $body = ['roles' => \array_keys($collector)];
                                        if (\IPS\brilliantdiscord\Behavior::i()->sync_nicknames) {
                                            $body['nick'] = $member['name'];
                                        }
                                        Log::logDebugMessage("[Mass Sync] Member {$member['name']} ({$member['token_member']}, discord {$user['user']['username']}#{$user['user']['discriminator']} ({$userId})) will be synchronized with roles: \n\n" . json_encode($body['roles']));
                                        RateLimit::limitHandle('guilds/{guild.id}/members/{member.id}', $gid, function ($check) use ($userId, $body, $gid, &$data, $member) {
                                            // Basic request settings
                                            $request = new Request("guilds/$gid/members/$userId");
                                            $request->applyDefaultHeaders();
                                            $request->bot();
                                            $response = $request->submit('PATCH', json_encode($body));

                                            // Check for rate limits
                                            $check($response);

                                            // The member left the discord server or something, that's fine
                                            if ($response->httpResponseCode == 404 && $response->decodeJson()['code'] == 10013) {
                                                return;
                                            }
                                            if ($response->httpResponseCode != 200) {
                                                (new UnhandledDiscordException($request, $response))->safeHandle(TRUE);
                                            }
                                        });
                                        $data['synced']++;
                                    }
                                } catch (\UnderflowException $e) {}
                                $data['checked']++;
                                $data['last_checked_id'] = $userId;
                            }
                            return \count($json) < $hardMemberLimit ? 'stop' : NULL;
                        });
                        if ($result == 'stop') {
                            return NULL;
                        }
                        $progress = min(0, max(100, round($data['checked'] / ($data['members'] ?: 1))));
                        return [$data, \IPS\Member::loggedIn()->language()->addToStack('brilliantdiscord_mass_sync_prog_syncing', false, ['sprintf' => [$data['checked'], $data['members'], $data['synced']]]), $progress];
                    } catch (RateLimitedException $e) {
                        if (!\is_array($data)) {
                            $data = ['complete' => false];
                        }
                        $data['wait_until'] = $e->reset_time;
                        $progress = min(0, max(100, round($data['checked'] / ($data['members'] ?: 1))));
                        return [$data, \IPS\Member::loggedIn()->language()->addToStack('brilliantdiscord_mass_sync_prog_syncing', false, ['sprintf' => [$data['checked'], $data['members'], $data['synced']]]), $progress];
                    }
                },
                function() {
                    \IPS\Output::i()->redirect(\IPS\Http\Url::internal('app=brilliantdiscord&module=general&controller=configuration&do=masssync&state=done'));
                }
            );
            \IPS\Output::i()->output = $multiRedirect;
        } elseif (\IPS\Request::i()->state == 'done') {
            \IPS\Output::i()->output = \IPS\Theme::i()->getTemplate('configuration', 'brilliantdiscord', 'admin')->massSyncComplete();
        } else {
            \IPS\Output::i()->error('page_not_found', '1sbr108/5', 404);
        }
    }

    // Create new methods with the same name as the 'do' parameter which should execute it
}