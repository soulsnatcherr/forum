<?php
/* Turkceye Ceviren eka7a - http://e-piksel.com */

// Text
$_['text_footer']  = 'Bu yazılım <a href="https://opencartuzmani.com" title="Opencart Uzmanı">Opencart Uzmanı</a> sitesinden indirilmiştir.';
$_['text_version'] = 'Sürüm %s';