<?php

namespace IPS\brilliantdiscord\api;

/* To prevent PHP errors (extending class does not exist) revealing path */

use IPS\brilliantdiscord\LoginHandler;
use IPS\brilliantdiscord\RateLimit\RateLimitedException;
use IPS\brilliantdiscord\Util\UnhandledDiscordException;

if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
    header( ( isset( $_SERVER['SERVER_PROTOCOL'] ) ? $_SERVER['SERVER_PROTOCOL'] : 'HTTP/1.0' ) . ' 403 Forbidden' );
    exit;
}

/**
 * @brief	Discord member API
 */
class _member extends \IPS\Api\Controller
{
    /**
     * GET /brilliantdiscord/member/{id}/invision
     * Get information about a specific Invision Community member by their Discord account ID
     *
     * @param		string		$id			Discord user ID
     * @apiparam	array		otherFields	An array of additional non-standard fields to return via the REST API
     * @throws		1SBR109/1	INVALID_ID	The member ID does not exist
     * @return		\IPS\Member
     */
    public function GETitem_invision($id)
    {
        try {
            $id = \IPS\Db::i()->select('token_member', 'core_login_links', ['token_login_method=? AND token_identifier=?', LoginHandler::i()->id, $id])->first();
            $member = \IPS\Member::load($id);
            if (!$member->member_id) {
                throw new \UnderflowException;
            }

            return new \IPS\Api\Response(200, $member->apiOutput($this->member, (isset(\IPS\Request::i()->otherFields)) ? \IPS\Request::i()->otherFields : NULL));
        } catch (\UnderflowException $e) {
            throw new \IPS\Api\Exception('INVALID_ID', '1SBR109/1', 404);
        }
    }

    /**
     * GET /brilliantdiscord/member/{id}/discord
     * Get information about a specific Discord user by their Invision Community member ID
     *
     * @param		string		$id						Invision Community member ID
     * @throws		1SBR109/8	INVALID_ID				The member ID does not exist
     * @throws		1SBR109/9	ACCOUNT_NOT_LINKED		Requested account is not linked with Discord
     * @throws		5SBR109/A	DISCORD_USER_NOT_FOUND	The linked account does not exist on Discord
     * @throws		1SBR109/B	RATE_LIMIT_EXCEEDED		The site cannot make a request to the api because of Rate Limits. Retry-After header indicates how much do you need to wait before trying again (in seconds)
     * @throws		1SBR109/C	UNHANDLED_DISCORD_ERROR	An unexpected Discord error has occurred. Try again later and contact Brilliant Discord Integration support if the issue persists.
     * @return		array
     * @apiresponse	string	id	Refer to Discord's documentation for details
     */
    public function GETitem_discord($id)
    {
        $member = \IPS\Member::load($id);
        if (!$member->member_id) {
            throw new \IPS\Api\Exception('INVALID_ID', '1SBR109/8', 404);
        }

        $uid = ($member->discordLink() ?: ['token_identifier' => NULL])['token_identifier'];
        if ($uid === null) {
            throw new \IPS\Api\Exception('ACCOUNT_NOT_LINKED', '1SBR109/9', 400);
        }

        try {
            $data = \IPS\brilliantdiscord\RateLimit::limitHandle('users/{user.id}', $uid, function ($check) use ($uid) {
                $request = new \IPS\brilliantdiscord\Request("users/$uid");
                $request->applyDefaultHeaders();
                $request->bot();
                $response = $request->submit();
                $check($response);
                switch ($response->httpResponseCode) {
                    case 200:
                        return $response->decodeJson();
                    case 404:
                        throw new \IPS\Api\Exception('DISCORD_USER_NOT_FOUND', '5SBR109/A', 404);
                    default:
                        (new \IPS\brilliantdiscord\Util\UnhandledDiscordException($request, $response))->safeHandle(false);
                        throw new \IPS\Api\Exception('UNHANDLED_DISCORD_ERROR', '5SBR109/C', 404);
                }
            });
            return new \IPS\Api\Response(200, $data);
        } catch (RateLimitedException $e) {
            \IPS\Output::i()->httpHeaders['Retry-After'] = $e->reset_time - time();
            throw new \IPS\Api\Exception('RATE_LIMIT_EXCEEDED', '1SBR109/B', 429);
        }
    }

    /**
     * GET /brilliantdiscord/member/{id}/sync
     * Synchronize data between Discord and Invision Community accounts with a specified ID
     *
     * @param		string		$id								Member ID (add a "discord:" prefix to the ID if you are providing a Discord user ID)
     * @throws		1SBR109/3	INVALID_ID						The member ID does not exist
     * @throws		1SBR109/4	MEMBER_NOT_LINKED				The account requested to get synchronized is not linked with Discord
     * @throws		4SBR109/5	INSUFFICIENT_BOT_PERMISSIONS	You are either trying to synchronize the Discord server owner or the bot has insufficient permissions (or is too low in role hierarchy) to synchronize that member.
     * @throws		1SBR109/6	MEMBER_NOT_ON_DISCORD			This account is not a member of the Discord server.
     * @return		string
     */
    public function GETitem_sync($id)
    {
        $isDiscordId = \mb_substr($id, 0, 8) == "discord:";

        try {
            if ($isDiscordId) {
                $id = \mb_substr($id, 8);
                $member = \IPS\Member::load(\IPS\Db::i()->select('token_member', 'core_login_links', ['token_login_method=? AND token_identifier=?', LoginHandler::i()->id, $id])->first());
            } else {
                $member = \IPS\Member::load($id);
            }
            if (!$member->member_id) {
                throw new \UnderflowException;
            }

            try {
                if (!$member->discordLink()) {
                    throw new \IPS\Api\Exception('MEMBER_NOT_LINKED', '1SBR109/7', 403);
                }
                $member->discordSync();
            } catch (RateLimitedException $e) {
                \IPS\Output::i()->httpHeaders['Retry-After'] = $e->reset_time - time();
                throw new \IPS\Api\Exception('RATE_LIMIT_EXCEEDED', '1SBR109/4', 429);
            } catch (\OutOfRangeException $e) {
                throw new \IPS\Api\Exception('INSUFFICIENT_BOT_PERMISSIONS', '4SBR109/5', 500);
            } catch (\UnderflowException $e) {
                throw new \IPS\Api\Exception('MEMBER_NOT_ON_DISCORD', '1SBR109/6', 403);
            }
            return new \IPS\Api\Response(200, "OK");
        } catch (\UnderflowException $e) {
            throw new \IPS\Api\Exception('INVALID_ID', '1SBR109/3', 404);
        }
    }
}